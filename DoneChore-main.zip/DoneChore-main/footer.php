
<style>
  footer{
    position: absolute;
  bottom: 0;
  width: 100%;
  height: 50px;
  }
</style>
<footer>
  Copyright 2022 
</footer>

</html>